from setuptools import setup

setup(
    name = 'RASD_TOOLBOX',
    version = '0.0.0',
    author = 'Prof. Wanderlei M. Pereira Junior, Prof. Romes Antônio Borges, Civil Eng. Donizetti Aparecido de Souza Júnior',
    author_email = 'wanderlei_junior@ufcat.edu.br',
    url='https://wmpjrufg.github.io/RASD_TOOLBOX/',
    packages = ['RASD_TOOLBOX']
)